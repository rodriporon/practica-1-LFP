# [LFP]Practica1 Archivos de Entrada

Universidad de San Carlos de Guatemala  
Facultad de Ingeniería  
Escuela de Ciencias y Sistemas  
Lenguajes Formales y de Programación  
Primer Semestre 2021

### [Archivo1.lfp](Archivo1.lfp)

```
TELEFONOS = 43553464,  35360521,  45645435,  54624354,  35445534,  34342234,  54453453,  53454345 BUSCAR 54453111, ORDENAR
N = 7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8,7,8 BUSCAR 8
DIGIT0S=9,  8,  7,  6,    4,  3,    2,  1,    0     ORDENAR,    BUSCAR 0
```

### Ejemplo Salida 

```sh
TELEFONOS: LISTA ORDENADA = 34342234, 35360521, 35445534, 43553464, 45645435, 53454345, 54453453, 54624354
TELEFONOS: 54453111 NO ENCONTRADO

N: POSICIONES DE 8 = 2,4,6,8,10,12,14,16,18,20,22,24,26,28,30

DIGIT0S: LISTA ORDENADA = 0,1,2,3,4,5,6,7,8,9
DIGIT0S: POSICIONES DE 0 = 9
```
